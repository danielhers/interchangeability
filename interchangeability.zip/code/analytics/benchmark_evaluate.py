import csv
import logging
import os
from argparse import ArgumentParser
from glob import glob

import spacy
from tqdm import tqdm

from evaluation.benchmark import BENCHMARKS, pearson

nlp = spacy.load("en", disable=("parser", "ner"))  # requires `python -m spacy download en'


def read_distances(filename):
    """
    Calculate vector of distances per model
    :param filename: .tsv file containing: term1, term2, [score by each model], ...
    :return: dict of model name -> array of distances
    """
    with open(filename, encoding="utf-8") as f:
        reader = csv.reader(f, delimiter="\t")
        headers = next(reader)
        rows = list(reader)
        model_distances = {}
        for term1, term2, *model_scores in tqdm(rows, desc="Reading " + filename, unit=" lines"):
            for header, score in zip(headers[2:], model_scores):
                if score:
                    model_name = header.rpartition("_score")[0]
                    try:
                        model_distances.setdefault(model_name, {})[(term1, term2)] = float(score)
                    except ValueError as e:
                        raise IOError("Invalid line in %s: %s" % (filename, "\t".join((term1, term2, score)))) from e
        return model_distances


def main(args):
    os.makedirs(args.out_dir, exist_ok=True)
    for pattern in args.distances:
        out_file = os.path.join(args.out_dir, os.path.splitext(os.path.basename(pattern))[0] + "_eval.tsv")
        with open(out_file, "w", encoding="utf-8") as f:
            for benchmark in BENCHMARKS:
                print(benchmark.name, end="\t", file=f)
                pairs = list(benchmark.load(verbose=False).itertuples(index=False))
                _, _, gold_scores = zip(*pairs)
                benchmark_pattern = os.path.join(os.path.dirname(pattern),
                                                 "_".join((benchmark.name, os.path.basename(pattern))))
                for filename in glob(benchmark_pattern) or [benchmark_pattern]:
                    logging.info(filename)
                    model_distances = read_distances(filename)
                    for model_name, distances in tqdm(sorted(model_distances.items()), desc="Analyzing", unit="model"):
                        pred_scores = [distances.get(p[:2], 0) for p in pairs]
                        print(pearson(pred_scores, gold_scores), end="\t", file=f)
                print(file=f)
        logging.info("Wrote '%s'" % out_file)


if __name__ == "__main__":
    argparser = ArgumentParser(description="Evaluate similarity scores for multiple models on multiple benchmarks")
    argparser.add_argument("distances", nargs="+", help="tsv file containing term1, term2, [score by each model], ...")
    argparser.add_argument("-o", "--out-dir", default=".", help="Directory to save report to")
    logging.basicConfig(filename=os.path.splitext(argparser.prog)[0] + ".log", level=logging.INFO)
    main(argparser.parse_args())
